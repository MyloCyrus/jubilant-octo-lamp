﻿![](Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.001.png)

13/25

Performance

0–4950–8990–100

![Final Screenshot](Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.002.jpeg)

` `FORMCHECKBOX 

METRICSExpand view

Total Blocking Time

8,730 ms

Cumulative Layout Shift

0\.683

Interaction to Next Paint

1,900 ms

View TraceView Treemap

![Screenshot](Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.003.jpeg)

![Screenshot]

![Screenshot]

![Screenshot]

![Screenshot]

![Screenshot](Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.006.jpeg)

![Screenshot](Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.007.jpeg)

![Screenshot](Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.008.jpeg)

![Screenshot](Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.009.jpeg)

![Screenshot](Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.010.jpeg)

Show audits relevant to:![ref1]All![ref1]TBT![ref1]CLS![ref1]INP

OPPORTUNITIES

Opportunity

Estimated Savings

Reduce unused JavaScript

7\.78 s

![ref2]

[](https://web.dev/unused-javascript/?utm_source=lighthouse&utm_medium=devtools)

||||
| :- | -: | -: |
|[](https://www.google.com/search?q=blue+html+code+snippets&oq=blue+html+code+snippets&aqs=chrome..69i57j69i59.4672j0j9&sourceid=chrome&ie=UTF-8)|||
|[](https://www.w3schools.com/howto/default_page6.asp)|||
|[](https://www.google.com/search?q=html+snippets&oq=html+snippets&aqs=chrome.0.0i512l10.4281j0j4&sourceid=chrome&ie=UTF-8)|||
Reduce unused CSS

1\.26 s

![ref2]

[](https://web.dev/unused-css-rules/?utm_source=lighthouse&utm_medium=devtools)

||||
| :- | -: | -: |
|[](https://www.xrstudios.live/css/app.css?id=5ebcfc0f8c11399c1816)|||
|[](https://www.w3schools.com/lib/w3schools32.css)|||
These suggestions can help your page load faster. They don't [directly affect](https://web.dev/performance-scoring/?utm_source=lighthouse&utm_medium=devtools) the Performance score.

DIAGNOSTICS

Use HTTP/2 26 requests not served via HTTP/2

![ref2]

[](https://web.dev/uses-http2/?utm_source=lighthouse&utm_medium=devtools)

|||
| :- | :- |
|[](https://www.xrstudios.live/press)||
|[](https://www.xrstudios.live/assets/XRs.svg)||
|[](https://www.xrstudios.live/assets/286171375_1659749074388392_5880687106147496343_n.jpg)||
|[](https://www.xrstudios.live/assets/BEP_GMA_SELECTS_0002s_0002_BEP_RITMO_GMA_T11_v-01.00_02_18_28.Still014-1624055176.png)||
|[](https://www.xrstudios.live/assets/rs.jpeg)||
|[](https://www.xrstudios.live/assets/variet.png)||
|[](https://www.xrstudios.live/assets/NEW-YORK-TIMES.jpg)||
|[](https://www.xrstudios.live/assets/WRAP.webp)||
|[](https://www.xrstudios.live/assets/dead.jpeg)||
|[](https://www.xrstudios.live/assets/BILLBOARD.jpeg)||
|[](https://www.xrstudios.live/assets/Rolling-STone.jpeg)||
|[](https://www.xrstudios.live/assets/NME.jpeg)||
|[](https://www.xrstudios.live/assets/Ellie-Goulding-Brightest-Blue.jpeg)||
|[](https://www.xrstudios.live/fonts/Aeonik-font/Aeonik-Light.otf)||
|[](https://www.xrstudios.live/fonts/Aeonik-font/Aeonik-Regular.otf)||
|[](https://www.xrstudios.live/fonts/Aeonik-font/Aeonik-Medium.otf)||
|[](https://www.xrstudios.live/fonts/Aeonik-font/Aeonik-Bold.otf)||
|[](https://www.xrstudios.live/assets/BILxr---13_BAD.png)||
|[](https://www.xrstudios.live/img/dotted-line.svg)||
|[](https://www.xrstudios.live/img/plus-btn.svg)||
|[](https://www.xrstudios.live/assets/LIVE-DESIGN.jpeg)||
|[](https://www.xrstudios.live/assets/LIVEDESIGN2.jpeg)||
|[](https://www.xrstudios.live/assets/notch.jpeg)||
|[](https://www.xrstudios.live/js/app.js?id=15bf56e392a528972f8e)||
|[](https://www.xrstudios.live/img/favicon-16x16.png)||
|[](https://www.xrstudios.live/img/favicon-32x32.png)||
Avoid enormous network payloads Total size was 13,683 KiB

![ref2]

[](https://web.dev/total-byte-weight/?utm_source=lighthouse&utm_medium=devtools)

|||
| :- | -: |
|[](https://www.xrstudios.live/assets/BILxr---13_BAD.png)||
|[](https://www.xrstudios.live/assets/BEP_GMA_SELECTS_0002s_0002_BEP_RITMO_GMA_T11_v-01.00_02_18_28.Still014-1624055176.png)||
|[](https://www.xrstudios.live/assets/rs.jpeg)||
|[](https://www.xrstudios.live/assets/Rolling-STone.jpeg)||
|[](https://107vod-adaptive.akamaized.net/exp=1691599302~acl=%2F5843e311-6c68-401d-9bb0-2ae78ebc8942%2F%2A~hmac=c6f15a28de9e1da3e402b558281149414f3bfde44950c1365358c5fb1c309a83/5843e311-6c68-401d-9bb0-2ae78ebc8942/parcel/video/2c020d9c.mp4?r=dXMtZWFzdDE%3D&range=58700627-63115871)||
|[](https://107vod-adaptive.akamaized.net/exp=1691599302~acl=%2F5843e311-6c68-401d-9bb0-2ae78ebc8942%2F%2A~hmac=c6f15a28de9e1da3e402b558281149414f3bfde44950c1365358c5fb1c309a83/5843e311-6c68-401d-9bb0-2ae78ebc8942/parcel/video/2c020d9c.mp4?r=dXMtZWFzdDE%3D&range=66731890-71296214)||
|[](https://www.xrstudios.live/assets/variet.png)||
|[](https://www.xrstudios.live/assets/BILLBOARD.jpeg)||
|[](https://www.google.com/xjs/_/js/k=xjs.s.en_US.p3nZyp6mbUw.O/ck=xjs.s.ypu7H_JuHzc.L.W.O/am=CgghIQAAAAACABD1hEMAG0AA_tkZAABAEAABAAAAAOAqAgADAMH7T9IAAAgQAmABxOANAEooATsAAACM_RABAAAAIA6A8QIgFALQgRBQAQQAAABAHoCcBwgOJiwAAAAAAAAAAACAAEoQDA5IjxUEQAAAAAAAAAAAAIBUMnkpEAIAag/d=0/excm=ABxRVc,AD6AIb,FmnE6b,JxE93,KzZUob,NsEUGe,Oa7Qpb,Ok4XMd,PoJj8d,SKZSKc,T3q8Wd,TO0csb,U3Ovcc,UiPhkb,VZLyBe,WxJ6g,XHo6qe,ZrXR8b,bXyZdf,cKV22c,du3Q4e,eTv59e,f26on,fNMhz,hfJ9hb,jkRPje,kOSi0d,rL2AR,tlA71,tzTB5,vJPFse,y25qZb,yChgtb/ed=1/dg=2/br=1/rs=ACT90oFSSRUynmc4RRpCqeqCOn03wSwqmw/m=WlNQGd,vTw9Fc,gSZvdb,sy1u9,SC7lYd,W0N1pf,syse,bpec7b,uKlGbf,sy7g,BYwJlf,sycc,syce,sycg,syk5,syk6,syk7,VEbNoe,sy1k3,sy1k4,sy1k5,b8OZff,sy1k6,qcH9Lc,syf5,YFicMc,sybg,syc1,syeb,sym5,syuv,Mbif2,sym4,sym6,sym7,DPreE,g0Ekse,sy107,sy108,p2I2Je,ARtdse,TnJGKb,SnmExf,syi7,syi8,syid,syic,syia,syi6,syi5,syif,syit,syiv,syiw,syiy,sy9f,sy9g,sy9h,syj1,syiz,syj0,sy95,sy98,sy9b,sy9c,sy94,syj3,syj4,syj5,syj7,syj2,syj9,syii,sy9m,sy9n,sy9v,sy9w,sy9x,sy9y,sy9z,sya0,sya1,sya2,sya3,sya4,sya5,sya6,sya7,sya8,sya9,syaa,syab,syac,syad,syae,syaf,syag,syah,syai,syaj,syms,symn,symo,symp,symq,symr,symm,symt,syuw,syux,sypl,syv0,syv1,syuz,syv2,syv3,syv5,sy109,sy10b,sy10a,sy10c,sy10d,sycl,sy10g,sybq,syc4,sy10i,sy10h,syph,sypg,sypi,sypj,sy10j,sy10k,sy10l,sy10m,sy10n,sy10o,sy10p,sy10q,sy9k,sy9o,sy10r,sy10s,sy10t,sy10u,sy10v,syb9,syct,sybm,sych,sycu,sy10e,sy10f,syat,syba,sybn,sybs,sybu,syc8,syco,sycp,sycq,sycr,sy10w,sy10x,sy10y,sy10z,sy110,sy111,sy113,sy9j,sy114,sy115,sy116,sy117,sy118,syb2,syak,syal,syam,sy119,sy11k,sy11l,sy11m,sy11n,syaq,sy11e,sy11h,sy11a,syan,syar,syau,syav,syaw,syax,syay,syaz,syb0,sy11c,sy11f,sy11g,sy11i,syao,syap,sy112,sy11j,sy11d,sy11b,syda,sybe,sybt,syc9,sydc,syca,syd7,sydb,sydd,sy11o,sy11p,sy11q,sycd,sy11r,sycx,sycy,sy11s,sycv,sycw,sy11u,sy11v,sy11t,sy11w,syd0,syd1,syd2,sy11x,sycz,sy11z,sy120,sy11y,sy121,sy122,sybb,sybo,syb3,sydq,sydr,sy128,sy123,sy124,sy125,sy127,sy126,sycm,sy129,syqb,sy12b,sy12a,sy12c,sy12d,sy12f,sy12e,sy12g,sy12h,syc2,sy12i,sy12j,sy12k,sy12l,exgaYe,syy0,DpX64d,EufiNb?xjs=s3)||
|[](https://www.xrstudios.live/assets/LIVE-DESIGN.jpeg)||
Serve static assets with an efficient cache policy 76 resources found

![ref2]

[](https://web.dev/uses-long-cache-ttl/?utm_source=lighthouse&utm_medium=devtools)

` `FORMCHECKBOX 

||||
| :- | -: | -: |
|[](https://www.xrstudios.live/assets/BILxr---13_BAD.png)|||
|[](https://www.xrstudios.live/assets/BEP_GMA_SELECTS_0002s_0002_BEP_RITMO_GMA_T11_v-01.00_02_18_28.Still014-1624055176.png)|||
|[](https://www.xrstudios.live/assets/rs.jpeg)|||
|[](https://www.xrstudios.live/assets/Rolling-STone.jpeg)|||
|[](https://www.xrstudios.live/assets/variet.png)|||
|[](https://www.xrstudios.live/assets/BILLBOARD.jpeg)|||
|[](https://www.xrstudios.live/assets/LIVE-DESIGN.jpeg)|||
|[](https://www.xrstudios.live/assets/286171375_1659749074388392_5880687106147496343_n.jpg)|||
|[](https://www.xrstudios.live/assets/notch.jpeg)|||
|[](https://www.xrstudios.live/assets/NME.jpeg)|||
|[](https://www.xrstudios.live/assets/LIVEDESIGN2.jpeg)|||
|[](https://www.xrstudios.live/assets/WRAP.webp)|||
|[](https://www.xrstudios.live/assets/NEW-YORK-TIMES.jpg)|||
|[](https://www.xrstudios.live/assets/dead.jpeg)|||
|[](https://www.xrstudios.live/assets/Ellie-Goulding-Brightest-Blue.jpeg)|||
|[](https://www.xrstudios.live/img/dotted-line.svg)|||
|[](https://www.xrstudios.live/img/plus-btn.svg)|||
|[](https://www.xrstudios.live/assets/XRs.svg)|||
|[](https://www.xrstudios.live/fonts/Aeonik-font/Aeonik-Bold.otf)|||
|[](https://www.xrstudios.live/fonts/Aeonik-font/Aeonik-Light.otf)|||
|[](https://www.xrstudios.live/fonts/Aeonik-font/Aeonik-Medium.otf)|||
|[](https://www.xrstudios.live/fonts/Aeonik-font/Aeonik-Regular.otf)|||
|[](https://www.xrstudios.live/img/favicon-16x16.png)|||
|[](https://www.xrstudios.live/js/app.js?id=15bf56e392a528972f8e)|||
|[](https://www.w3schools.com/lib/fonts/SourceSansPro-Regular.woff2)|||
|[](https://www.html.am/common/css/vendor/font-awesome/font-awesome-4.4.0/fonts/fontawesome-webfont.woff2?v=4.4.0)|||
|[](https://www.w3schools.com/howto/img_forest.jpg)|||
|[](https://www.w3schools.com/howto/img_nature_wide.jpg)|||
|[](https://www.w3schools.com/lib/fonts/freckle-face-v9-latin-regular.woff2)|||
|[](https://www.w3schools.com/howto/img_paris.jpg)|||
|[](https://www.w3schools.com/lib/uic.js?v=1.0.5)|||
|[](https://www.w3schools.com/howto/timeline.jpg)|||
|[](https://www.w3schools.com/lib/fonts/source-sans-pro-v14-latin-600.woff2)|||
|[](https://www.w3schools.com/lib/fonts/source-sans-pro-v14-latin-700.woff2)|||
|[](https://www.w3schools.com/lib/w3schools32.css)|||
|[](https://www.w3schools.com/lib/fonts/source-code-pro-v14-latin-regular.woff2)|||
|[](https://www.w3schools.com/lib/w3schools_footer.js?update=20230706)|||
|[](https://www.w3schools.com/lib/fonts/roboto-mono-v13-latin-500.woff2)|||
|[](https://www.w3schools.com/lib/fonts/fontawesome.woff2?14663396)|||
|[](https://www.w3schools.com/w3images/bandmember.jpg)|||
|[](https://www.w3schools.com/howto/howto.css)|||
|[](https://www.w3schools.com/lib/user-session.js?v=1.0.29)|||
|[](https://www.w3schools.com/w3images/avatar2.png)|||
|[](https://www.w3schools.com/howto/img_avatar2.png)|||
|[](https://www.w3schools.com/howto/img_avatar.png)|||
|[](https://www.w3schools.com/w3images/avatar5.png)|||
|[](https://www.html.am/common/css/fontawesome.css)|||
|[](https://www.w3schools.com/lib/my-learning.js?v=1.0.21)|||
|[](https://www.html.am/common/css/base.css)|||
|[](https://www.w3schools.com/lib/common-deps.js?v=1.0.2)|||
|[](https://www.html.am/common/css/html.css)|||
|[](https://www.html.am/common/js/Prism/themes/custom.css)|||
|[](https://www.w3schools.com/signup/lynxlogo.svg)|||
|[](https://www.html.am/common/js/jquery.autosize-min.js)|||
|[](https://www.w3schools.com/howto/howto.js)|||
|[](https://www.html.am/images/favicon.ico)|||
|[](https://static.cloudflareinsights.com/beacon.min.js/v8b253dfea2ab4077af8c6f58422dfbfd1689876627854)|||
|[](https://www.gstatic.com/prose/brandjs.js)|||
|[](https://tpc.googlesyndication.com/pagead/images/transparent.png)|||
|[](https://lh3.googleusercontent.com/ogw/AGvuzYbKH8mpj8onZn5Hq3SF4R2Dn3Nlw5G3L-fqpq7J7w=s32-c-mo)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/one_click_handler_one_afma_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/abg_lite_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/abg_lite_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/qs_click_protection_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/window_focus_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/window_focus_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/load_preloaded_resource_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/load_preloaded_resource_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/abg_lite_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/qs_click_protection_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/qs_click_protection_fy2021.js)|||
|[](https://tpc.googlesyndication.com/pagead/js/r20230807/r20110914/client/window_focus_fy2021.js)|||
|[](https://www.gstatic.com/mysidia/1ecb17048d796ff7836f25d4dc1a1361.js?tag=mysidia_one_click_handler_one_afma_2019)|||
|[](https://www.gstatic.com/mysidia/12e0c0bbc282de0324fc2c716af124fb.js?tag=client_fast_engine_2019)|||
|[](https://www.gstatic.com/mysidia/17b11504dbe358eca20ea232cf228787.js?tag=text/vanilla_highlight)|||
|[](https://www.gstatic.com/mysidia/12e0c0bbc282de0324fc2c716af124fb.js?tag=client_fast_engine_2019)|||
Minimize main-thread work 17.9 s

![ref2]

[](https://web.dev/mainthread-work-breakdown/?utm_source=lighthouse&utm_medium=devtools)

|||
| :- | -: |
|||
|||
|||
|||
|||
|||
|||
Reduce the impact of third-party code Third-party code blocked the main thread for 2,050 ms

![ref2]

[](https://developers.google.com/web/fundamentals/performance/optimizing-content-efficiency/loading-third-party-javascript/?utm_source=lighthouse&utm_medium=devtools)

||||
| :-: | -: | -: |
|[](https://code.jquery.com/)|||
|[](https://www.akamai.com/)|||
|[](https://107vod-adaptive.akamaized.net/exp=1691599302~acl=%2F5843e311-6c68-401d-9bb0-2ae78ebc8942%2F%2A~hmac=c6f15a28de9e1da3e402b558281149414f3bfde44950c1365358c5fb1c309a83/5843e311-6c68-401d-9bb0-2ae78ebc8942/parcel/video/2c020d9c.mp4?r=dXMtZWFzdDE%3D&range=58700627-63115871)|||
|[](https://107vod-adaptive.akamaized.net/exp=1691599302~acl=%2F5843e311-6c68-401d-9bb0-2ae78ebc8942%2F%2A~hmac=c6f15a28de9e1da3e402b558281149414f3bfde44950c1365358c5fb1c309a83/5843e311-6c68-401d-9bb0-2ae78ebc8942/parcel/video/2c020d9c.mp4?r=dXMtZWFzdDE%3D&range=66731890-71296214)|||
|[](https://107vod-adaptive.akamaized.net/exp=1691599302~acl=%2F5843e311-6c68-401d-9bb0-2ae78ebc8942%2F%2A~hmac=c6f15a28de9e1da3e402b558281149414f3bfde44950c1365358c5fb1c309a83/5843e311-6c68-401d-9bb0-2ae78ebc8942/parcel/video/2c020d9c.mp4?r=dXMtZWFzdDE%3D&range=63115872-66731889)|||
|[](https://developers.google.com/apis-explorer/#p/)|||
|[](https://www.google.com/xjs/_/js/k=xjs.s.en_US.p3nZyp6mbUw.O/ck=xjs.s.ypu7H_JuHzc.L.W.O/am=CgghIQAAAAACABD1hEMAG0AA_tkZAABAEAABAAAAAOAqAgADAMH7T9IAAAgQAmABxOANAEooATsAAACM_RABAAAAIA6A8QIgFALQgRBQAQQAAABAHoCcBwgOJiwAAAAAAAAAAACAAEoQDA5IjxUEQAAAAAAAAAAAAIBUMnkpEAIAag/d=0/excm=ABxRVc,AD6AIb,FmnE6b,JxE93,KzZUob,NsEUGe,Oa7Qpb,Ok4XMd,PoJj8d,SKZSKc,T3q8Wd,TO0csb,U3Ovcc,UiPhkb,VZLyBe,WxJ6g,XHo6qe,ZrXR8b,bXyZdf,cKV22c,du3Q4e,eTv59e,f26on,fNMhz,hfJ9hb,jkRPje,kOSi0d,rL2AR,tlA71,tzTB5,vJPFse,y25qZb,yChgtb/ed=1/dg=2/br=1/rs=ACT90oFSSRUynmc4RRpCqeqCOn03wSwqmw/m=WlNQGd,vTw9Fc,gSZvdb,sy1u9,SC7lYd,W0N1pf,syse,bpec7b,uKlGbf,sy7g,BYwJlf,sycc,syce,sycg,syk5,syk6,syk7,VEbNoe,sy1k3,sy1k4,sy1k5,b8OZff,sy1k6,qcH9Lc,syf5,YFicMc,sybg,syc1,syeb,sym5,syuv,Mbif2,sym4,sym6,sym7,DPreE,g0Ekse,sy107,sy108,p2I2Je,ARtdse,TnJGKb,SnmExf,syi7,syi8,syid,syic,syia,syi6,syi5,syif,syit,syiv,syiw,syiy,sy9f,sy9g,sy9h,syj1,syiz,syj0,sy95,sy98,sy9b,sy9c,sy94,syj3,syj4,syj5,syj7,syj2,syj9,syii,sy9m,sy9n,sy9v,sy9w,sy9x,sy9y,sy9z,sya0,sya1,sya2,sya3,sya4,sya5,sya6,sya7,sya8,sya9,syaa,syab,syac,syad,syae,syaf,syag,syah,syai,syaj,syms,symn,symo,symp,symq,symr,symm,symt,syuw,syux,sypl,syv0,syv1,syuz,syv2,syv3,syv5,sy109,sy10b,sy10a,sy10c,sy10d,sycl,sy10g,sybq,syc4,sy10i,sy10h,syph,sypg,sypi,sypj,sy10j,sy10k,sy10l,sy10m,sy10n,sy10o,sy10p,sy10q,sy9k,sy9o,sy10r,sy10s,sy10t,sy10u,sy10v,syb9,syct,sybm,sych,sycu,sy10e,sy10f,syat,syba,sybn,sybs,sybu,syc8,syco,sycp,sycq,sycr,sy10w,sy10x,sy10y,sy10z,sy110,sy111,sy113,sy9j,sy114,sy115,sy116,sy117,sy118,syb2,syak,syal,syam,sy119,sy11k,sy11l,sy11m,sy11n,syaq,sy11e,sy11h,sy11a,syan,syar,syau,syav,syaw,syax,syay,syaz,syb0,sy11c,sy11f,sy11g,sy11i,syao,syap,sy112,sy11j,sy11d,sy11b,syda,sybe,sybt,syc9,sydc,syca,syd7,sydb,sydd,sy11o,sy11p,sy11q,sycd,sy11r,sycx,sycy,sy11s,sycv,sycw,sy11u,sy11v,sy11t,sy11w,syd0,syd1,syd2,sy11x,sycz,sy11z,sy120,sy11y,sy121,sy122,sybb,sybo,syb3,sydq,sydr,sy128,sy123,sy124,sy125,sy127,sy126,sycm,sy129,syqb,sy12b,sy12a,sy12c,sy12d,sy12f,sy12e,sy12g,sy12h,syc2,sy12i,sy12j,sy12k,sy12l,exgaYe,syy0,DpX64d,EufiNb?xjs=s3)|||
|[](https://www.google.com/xjs/_/js/k=xjs.s.en_US.p3nZyp6mbUw.O/ck=xjs.s.ypu7H_JuHzc.L.W.O/am=CgghIQAAAAACABD1hEMAG0AA_tkZAABAEAABAAAAAOAqAgADAMH7T9IAAAgQAmABxOANAEooATsAAACM_RABAAAAIA6A8QIgFALQgRBQAQQAAABAHoCcBwgOJiwAAAAAAAAAAACAAEoQDA5IjxUEQAAAAAAAAAAAAIBUMnkpEAIAag/d=0/excm=ABxRVc,AD6AIb,FmnE6b,JxE93,KzZUob,NsEUGe,Oa7Qpb,Ok4XMd,PoJj8d,SKZSKc,T3q8Wd,TO0csb,U3Ovcc,UiPhkb,VZLyBe,WxJ6g,XHo6qe,ZrXR8b,bXyZdf,cKV22c,du3Q4e,eTv59e,f26on,fNMhz,hfJ9hb,jkRPje,kOSi0d,rL2AR,tlA71,tzTB5,vJPFse,y25qZb,yChgtb/ed=1/dg=2/br=1/rs=ACT90oFSSRUynmc4RRpCqeqCOn03wSwqmw/m=sb_wiz,aa,abd,syla,sylg,sylc,sylq,sytf,async,sy12m,bgd,syu6,foot,sy244,sy2gx,kyn,sy1ix,lli,mu,sf,syub,syuc,sy25r,sonic,sy74,sy103,sy2r6,spch,sy26f,tl,sdH3v,symy,syn4,syk2,syqx,syqy,syqz,sy306,sy307,EkevXb,MpJwZc,syix,syma,sym9,symf,syny,SMquOb,sym8,symh,syo1,syo2,syo3,d5EhJe,sy21,sy7m,uxMpU,sy1l,sy1m,byfTOb,sy1p,lsjVmc,sy2k,OTA3Ae,sy2h,sy2i,sy2j,COQbmf,PoEs9b,U0aPgd,RagDlc,fVaWL,vRe0ve,sy2r7,oWVrne,ROaKxe,GU4Gab,T5VV,aDVF7,rhYw1b,Zilivc,E9M6Uc,XO2lNe,sy1n,sy1o,sy1q,sy1r,LEikZe,sy2rh,sy2ri,xfmZMb,nMfH9e,syk1,L1AAkb,Mlhmy,syqv,syqw,CnSW2d,syr7,EbPKJf,synl,syni,synk,synj,synm,synn,syno,syr9,syra,pFsdhd,oUlnpc,synr,synw,sy1tw,sy1tx,sy1tz,sy31m,sy372,Da4hkd,syff,syn2,sy134,synv,sy1gq,sy1gr,sy1gt,sy1gu,syke,sysh,sysi,sysj,sy1gs,sy1gv,sy1gw,sy1gx,sy1gy,aD8OEe,fiAufb,sysm,Gg40M,syt2,syt5,sypn,syt3,sy3n,sy81,syp8,syp9,syp4,syp5,syp6,syp7,syp3,sypb,sypc,sypa,sypd,sype,sypr,sypp,syt6,sypt,sypw,sypx,sypy,syps,syt7,syt8,sytl,syui,syuj,Hlw0zd,sy1k2,pj8IAe,SZXsif,synt,syql,syqk,sy13a,sy1ld,sy1lc,sy2sd,sYEX8b,syul,MTV2Lb,uY49fb,sy2d,sy2e,sy2s,OmgaI,sy1u,sy1v,sy1w,sy1t,sy1y,sy1x,fKUV3e,aurFic,EEDORb,Pjplud,QGR0gd,sy2m,sy2n,sy2o,kWgXee,sykd,syk8,sykb,sykc,syls,sylr,syqp,sysl,sy137,syn5,sy13y,sy13z,sy1k7,sy1uo,sy2r8,ogmBcd,ovKuLd,sy3c,sy3g,sy48,sy49,sy3t,sy4a,sy4f,sy3k,sy43,sy3u,sy3r,sy3w,sy3x,sy46,sy47,sy3v,sy3y,sy4r,sy38,sy3b,sy39,sy3a,sy53,sy5n,sy54,sy58,sy55,sy56,sy57,sy52,sy4b,sy33,sy34,sy3f,sy3h,sy35,sy3m,sy3o,sy3p,sy3l,sy40,sy3z,sy3s,sy45,sy44,sy3q,sy5c,sy5d,sy5g,sy5h,sy5e,sy5i,sy3i,sy3j,sy4c,sy5j,sy5k,sy5l,sy4x,sy4y,sy5o,sy5p,sy5m,sy59,sy4s,sy7u,sy7v,sy7w,sy7x,sy7y,sy7z,sy80,sy83,sy82,sy84,sy86,sy85,sy87,sy7f,sy8a,sy7t,sy8d,sy8e,sy7q,sy7r,sy7s,sy8f,sy8c,sy8b,sy7o,sy7p,sy8h,sy8i,sy8j,sy8g,sy8n,sy8m,sy8k,sy8o,sy8p,sy8q,sy8r,sy8s,sy8t,sy8u,sy8x,sy8w,sy8y,sy8v,sgY6Zb,io8t5d,KG2eXe,Oj465e,symg,syo9,syob,syoc,T1HOxc,syo4,syo5,syo6,syo7,syo8,zx30Y,symc,symd,Wo3n8,UUJqVe,sy1k,sOXFj,sy1j,sy2t,s39S4,NTMZac,nAFL3,oGtAuc,sy2b,sy2c,q0xTif,syz2,syz3,syz4,syig,syz6,syz5,syz7,sy19f,sy1iu,syz8,syz9,sy15d,sy15e,sy15f,syzg,sy15j,sy15k,sy15i,syj8,sy15l,sy7b,syi9,sy15n,sy15m,sy15o,sy15p,sy15q,sy15u,sy15y,sy163,sy9a,sycs,sy1l6,sy1l7,sy15x,sy161,sy162,sy166,sy169,sy16b,sy2j7,sy2j8,sy2s5,sy2s7,sy2s8,epYOx?xjs=s3)|||
|[](https://www.google.com/search?q=html+snippets&oq=html+snippets&aqs=chrome.0.0i512l10.4281j0j4&sourceid=chrome&ie=UTF-8)|||
|[](https://www.google.com/search?q=blue+html+code+snippets&oq=blue+html+code+snippets&aqs=chrome..69i57j69i59.4672j0j9&sourceid=chrome&ie=UTF-8)|||
|[](https://www.google.com/xjs/_/js/k=xjs.s.en_US.p3nZyp6mbUw.O/ck=xjs.s.ypu7H_JuHzc.L.W.O/am=CgghIQAAAAACABD1hEMAG0AA_tkZAABAEAABAAAAAOAqAgADAMH7T9IAAAgQAmABxOANAEooATsAAACM_RABAAAAIA6A8QIgFALQgRBQAQQAAABAHoCcBwgOJiwAAAAAAAAAAACAAEoQDA5IjxUEQAAAAAAAAAAAAIBUMnkpEAIAag/d=1/exm=SNUn3,attn,cEt90b,cdos,csi,d,dtl0hd,eHDfl,gwc,hsm,jsa,mb4ZUb,qddgKe,sTsDMc/excm=ABxRVc,AD6AIb,FmnE6b,JxE93,KzZUob,NsEUGe,Oa7Qpb,Ok4XMd,PoJj8d,SKZSKc,T3q8Wd,TO0csb,U3Ovcc,UiPhkb,VZLyBe,WxJ6g,XHo6qe,ZrXR8b,bXyZdf,cKV22c,du3Q4e,eTv59e,f26on,fNMhz,hfJ9hb,jkRPje,kOSi0d,rL2AR,tlA71,tzTB5,vJPFse,y25qZb,yChgtb/ed=1/dg=2/br=1/rs=ACT90oFSSRUynmc4RRpCqeqCOn03wSwqmw/ee=AfeaP:TkrAjf;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;Erl4fe:FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;IoGlCf:b5lhvb;JXS8fb:Qj0suc;JsbNhc:Xd8iUd;K8vqCc:MyIcle;KQzWid:mB4wNe;KcokUb:KiuZBf;KpRAue:Tia57b;LBgRLc:SdcwHb,XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:SdcwHb;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;Oj465e:KG2eXe;Pjplud:EEDORb,PoEs9b;PqHfGe:im2cZe;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R2kc8b:ALJqWb;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;SLtqO:Kh1xYe;SMDL4c:fTfGO,vjQg0b;SNUn3:ZwDk9d,x8cHvb;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;YV5bee:IvPZ6d;ZWEUA:afR4Cf;ZrFutb:W4Cdfc;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;hK67qb:QWEO5b;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kY7VAf:d91TEb;kbAm9d:MkHyGd;l8Azde:j4Ca9b;lkq0A:Z0MWEf;lzgfYb:PI40bd;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,vjQg0b;oUlnpc:RagDlc;okUaUd:wItadb;pNsl2d:j9Yuyc;pXdRYb:JKoKVe,MdUzUe;pj82le:mg5CW;qGV2uc:HHi04c;qaS3gd:yiLg6e;qavrXe:mYbt1d,zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uknmt:GkPrzb;uuQkY:u2V3ud;vfVwPd:OXTqFb;w3bZCb:ZPGaIb;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:O1Gjze,TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;xbe2wc:uRMPBc;xqZiqf:wmnU7d;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zxnPse:GkRiKb/m=Eox39d,FmAr0c,GElbSc,HYSCof,M9mgyc,fcDBE,pHXghd,tIj4fb,tboZfc,vrkJ0e?xjs=s1)|||
||||
|[](https://marketingplatform.google.com/about/enterprise/)|||
|[](https://pagead2.googlesyndication.com/pagead/managed/js/adsense/m202308030101/show_ads_impl_fy2021.js?bust=31076830)|||
|[](https://www.googletagservices.com/activeview/js/current/rx_lidar.js?cache=r20110914)|||
|[](https://pagead2.googlesyndication.com/pagead/managed/js/adsense/m202308030101/reactive_library_fy2021.js?bust=31076830)|||
|[](https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js)|||
|[](https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-6331358926293806&output=html&adk=1812271804&adf=3025194257&lmt=1691597495&plat=3%3A2162688%2C4%3A2162688%2C9%3A32768%2C16%3A8388608%2C17%3A32%2C24%3A32%2C25%3A32%2C30%3A1048576%2C32%3A32%2C41%3A32%2C42%3A32&format=0x0&url=https%3A%2F%2Fwww.html.am%2Fhtml-codes%2Fcolor%2Fhtml-blue-code.cfm&ea=0&pra=7&wgl=1&uach=WyJtYWNPUyIsIjEwLjE1LjciLCJ4ODYiLCIiLCI5OC4wLjQ2OTUuMCIsW10sMCxudWxsLCI2NCIsW1siTm90X0EgQnJhbmQiLCI5OS4wLjAuMCJdLFsiR29vZ2xlIENocm9tZSIsIjEwOS4wLjU0MTQuMTIwIl0sWyJDaHJvbWl1bSIsIjEwOS4wLjU0MTQuMTIwIl1dLDBd&dt=1691597493779&bpp=7&bdt=7664&idt=2180&shv=r20230807&mjsv=m202308030101&ptt=9&saldr=aa&abxe=1&prev_fmts=452x376&nras=1&correlator=6462315687278&frm=20&pv=1&ga_vid=1042671081.1691597494&ga_sid=1691597496&ga_hid=1136731644&ga_fc=1&ga_wpids=UA-269964-15&u_tz=-420&u_his=7&u_h=768&u_w=1024&u_ah=728&u_aw=1024&u_cd=24&u_sd=1&dmc=2&adx=-12245933&ady=-12245933&biw=452&bih=568&scr_x=0&scr_y=0&eid=44759842%2C44759875%2C44759926%2C31076685%2C31076687%2C31076688%2C31076730%2C31076830&oid=2&pvsid=1853063902102469&tmod=433838838&uas=1&nvt=1&fsapi=1&ref=https%3A%2F%2Fwww.google.com%2F&fc=896&brdim=0%2C0%2C0%2C0%2C1024%2C0%2C1024%2C728%2C469%2C568&vis=1&rsz=%7C%7Cs%7C&abl=NS&fu=32768&bc=31&ifi=4&uci=a!4&fsb=1&dtd=2207)|||
||||
|[](https://fonts.google.com/)|||
|[](https://fonts.gstatic.com/s/cabinsketch/v19/QGY2z_kZZAGCONcK2A4bGOj0I_1Y5tjzAYOcFg.woff2)|||
|[](https://fonts.gstatic.com/s/googlesans/v58/4UasrENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RPjIUvQ.woff2)|||
|[](https://fonts.gstatic.com/s/delius/v15/PN_xRfK0pW_9e1rdZsg_rz7b_g.woff2)|||
|[](https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7lujVj9w.woff2)|||
|[](https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlxdu3cOWxw.woff2)|||
||||
|[](https://marketingplatform.google.com/about/tag-manager/)|||
|[](https://www.googletagmanager.com/gtag/js?id=G-8VZWZEGMH6)|||
|[](https://www.googletagmanager.com/gtm.js?id=GTM-KTCFC3S)|||
|[](https://developers.google.com/speed/libraries/)|||
|[](https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js)|||
|[](https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js)|||
|[](https://www.gstatic.com/mysidia/1ecb17048d796ff7836f25d4dc1a1361.js?tag=mysidia_one_click_handler_one_afma_2019)|||
|[](https://www.gstatic.com/prose/brandjs.js)|||
||||
|[](https://cdnjs.com/)|||
|[](https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/fonts/fontawesome-webfont.woff2?v=4.6.3)|||
|[](https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css)|||
|[](https://www.cloudflare.com/website-optimization/)|||
|[](https://static.cloudflareinsights.com/beacon.min.js/v8b253dfea2ab4077af8c6f58422dfbfd1689876627854)|||
|[](https://www.bidswitch.com/)|||
||||
||||
|[](https://www.mediamath.com/)|||
||||
||||
|[](https://marketingplatform.google.com/about/analytics/)|||
||||
||||
|[](https://vimeo.com/)|||
|[](https://www.bootstrapcdn.com/)|||
|[](https://ad.amazon.com/)|||
Minimize work during key interaction 1,900 ms spent on event 'mousedown'

![ref2]

[](https://web.dev/inp/?utm_source=lighthouse&utm_medium=devtools)

||
| :- |
|<p></p><p></p>|


||||||
| :- | -: | -: | -: | -: |
||||||
||||||
||||||
|[](https://code.jquery.com/jquery-3.1.1.min.js)|||||
Reduce JavaScript execution time 7.8 s

![ref2]

[](https://web.dev/bootup-time/?utm_source=lighthouse&utm_medium=devtools)

` `FORMCHECKBOX 

|||||
| :- | -: | -: | -: |
|||||
|[](https://code.jquery.com/jquery-3.1.1.min.js)||||
|[](https://www.xrstudios.live/press)||||
|[](https://www.html.am/html-codes/color/html-blue-code.cfm)||||
|[](https://www.xrstudios.live/js/app.js?id=15bf56e392a528972f8e)||||
|||||
|[](https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js)||||
|||||
Keep request counts low and transfer sizes small 320 requests • 13,683 KiB

![ref2]

[](https://web.dev/use-lighthouse-for-performance-budgets/?utm_source=lighthouse&utm_medium=devtools)

||||
| :- | -: | -: |
||||
||||
||||
||||
||||
||||
||||
||||
||||
Avoid large layout shifts 4 elements found

![ref2]

|||
| :- | -: |
|||
|<p></p><p></p>||
|<p></p><p></p>||
|<p></p><p></p>||
Avoid long main-thread tasks 20 long tasks found

![ref2]

[](https://web.dev/long-tasks-devtools/?utm_source=lighthouse&utm_medium=devtools)

` `FORMCHECKBOX 

||||
| :- | -: | -: |
||||
|[](https://code.jquery.com/jquery-3.1.1.min.js)|||
||||
|[](https://www.xrstudios.live/press)|||
||||
||||
|[](https://code.jquery.com/jquery-3.1.1.min.js)|||
|[](https://code.jquery.com/jquery-3.1.1.min.js)|||
|[](https://www.xrstudios.live/js/app.js?id=15bf56e392a528972f8e)|||
|[](https://www.html.am/html-codes/color/html-blue-code.cfm)|||
|[](https://www.xrstudios.live/js/app.js?id=15bf56e392a528972f8e)|||
||||
||||
|[](https://code.jquery.com/jquery-3.1.1.min.js)|||
|[](https://www.xrstudios.live/js/app.js?id=15bf56e392a528972f8e)|||
|[](https://www.xrstudios.live/js/app.js?id=15bf56e392a528972f8e)|||
||||
||||
||||
|[](https://www.html.am/html-codes/color/html-blue-code.cfm)|||
Avoid non-composited animations 4 animated elements found

![ref2]

[](https://web.dev/non-composited-animations?utm_source=lighthouse&utm_medium=devtools)

|||
| :- | :- |
|<p></p><p></p>||
|||
|<p></p><p></p>||
|||
|<p></p><p></p>||
|||
|<p></p><p></p>||
|||
More information about the performance of your application. These numbers don't [directly affect](https://web.dev/performance-scoring/?utm_source=lighthouse&utm_medium=devtools) the Performance score.

PASSED AUDITS (15)

Show

![ref2]

[](https://web.dev/uses-responsive-images/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/unminified-css/?utm_source=lighthouse&utm_medium=devtools)

||||
| :- | -: | -: |
|[](https://www.w3schools.com/howto/howto.css)|||
![ref2]

[](https://web.dev/unminified-javascript/?utm_source=lighthouse&utm_medium=devtools)

![ref2]




















[](https://web.dev/uses-optimized-images/?utm_source=lighthouse&utm_medium=devtools)

![ref2]






















[](https://web.dev/uses-webp-images/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/uses-text-compression/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/time-to-first-byte/?utm_source=lighthouse&utm_medium=devtools)

|||
| :- | -: |
|[](https://www.html.am/html-codes/color/html-blue-code.cfm)||
![ref2]

[](https://web.dev/efficient-animated-content/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

![ref2]

[](https://philipwalton.com/articles/deploying-es2015-code-in-production-today/)

![ref2]

[](https://web.dev/user-timings/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/uses-passive-event-listeners/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/no-document-write/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/optimize-cls/?utm_source=lighthouse&utm_medium=devtools#images-without-dimensions)

![ref2]

[](https://web.dev/bfcache/?utm_source=lighthouse&utm_medium=devtools#never-use-the-unload-event)

5/7

Best Practices

GENERAL

Browser errors were logged to the console

![ref2]

[](https://web.dev/errors-in-console/?utm_source=lighthouse&utm_medium=devtools)

` `FORMCHECKBOX 

|||
| :- | :- |
|[](https://www.xrstudios.live/assets/PXL_20220714_175201977-1673024111.jpg)||
|[](https://www.xrstudios.live/img/playBtn.svg)||
|[](https://www.xrstudios.live/img/plus-btn.svg)||
|[](https://www.xrstudios.live/img/CROSS-BIG-SIZE.svg)||
|[](https://www.xrstudios.live/img/favicon-32x32.png)||
|[](https://www.xrstudios.live/assets/d3.jpeg)||
|[](https://www.xrstudios.live/assets/Screen-Shot-2021-06-25-at-4.28.19-PM.png)||
|[](https://www.xrstudios.live/assets/av.jpeg)||
|[](https://www.xrstudios.live/img/favicon-32x32.png)||
|[](https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js)||
|||
Issues were logged in the Issues panel in Chrome Devtools

![ref2]

||
| :- |
||
|[](https://www.googleadservices.com/measurement?jaid=AJHaeXLDEWq5gjeHKKvDg2x9PE4a3bPOgBQfwG4c3tu_KE1uShWbPpfl6NY&jaidet=19845)|
|[](https://cse.google.com/cse/brand?form=cse-search-box-bottom&lang=en)|
|[](https://www.google.com/pagead/drt/ui)|
|[](https://www.google.com/ads/measurement/l?ebcid=ALh7CaRtmgs8SYSuRDxXKafTQDgbImpl63bkFFtmerfKUczBYsdF0c7i5Afo9yKbwiTwkqSX2tjuRhR-cLpNVZTcUCwDUKbvSA)|
|[](https://www.google.com/ads/measurement/l?ebcid=ALh7CaSRnVSZoOQ-FvDkPINK1wT-c4kkoAxMjA9GXjty8d6exfJCRWqyIQ_-eBnpQcxZ4q8BXHQuJiorBkg6K13GoLarFMtesQ)|
|[](https://a.tribalfusion.com/i.match?p=b6&u=&google_push=AXcoOmRGswSHo5dmTq-KpFP6DNAgs2srHqzR9AKGdE-l4ZK-rygxZ5Mk5gxOG6GkxdPfy0YTeeNHU-7GXuo1eNpGYZj7U0Xx0vgbp7bk3THsuGOuEUmY02YD0rOBK7LwDI1tE-cin_yiXtWo97KEuqV72cEGxg&redirect=https%3A//cm.g.doubleclick.net/pixel%3Fgoogle_nid%3Dexp%26google_push%3DAXcoOmRGswSHo5dmTq-KpFP6DNAgs2srHqzR9AKGdE-l4ZK-rygxZ5Mk5gxOG6GkxdPfy0YTeeNHU-7GXuo1eNpGYZj7U0Xx0vgbp7bk3THsuGOuEUmY02YD0rOBK7LwDI1tE-cin_yiXtWo97KEuqV72cEGxg%26google_ula%3D2786954%26google_hm%3D%24TF_USER_ID_ENC%24)|
|[](https://a.tribalfusion.com/i.match?p=b6&u=&google_push=AXcoOmSCDlAEMt4OD8QbAHXtKpy_9BcXu5y6OUy5AiBb-8wYqeYHTVtHLJk0eusJuHcqAJvFvShHuBlVqPqj8qWBIoE0jHw6ei2xlCqB_38ndxnsgPZRWGBeDlUYg-yaTcUE7vHJLQOH78TVQKHitgkqfkFn&redirect=https%3A//cm.g.doubleclick.net/pixel%3Fgoogle_nid%3Dexp%26google_push%3DAXcoOmSCDlAEMt4OD8QbAHXtKpy_9BcXu5y6OUy5AiBb-8wYqeYHTVtHLJk0eusJuHcqAJvFvShHuBlVqPqj8qWBIoE0jHw6ei2xlCqB_38ndxnsgPZRWGBeDlUYg-yaTcUE7vHJLQOH78TVQKHitgkqfkFn%26google_ula%3D2786954%26google_hm%3D%24TF_USER_ID_ENC%24)|
|[](https://www.google.com/ads/measurement/l?ebcid=ALh7CaSuejA0T_twBndaqyZZ8rKVqPPcdFpLAixy0o96MjVJz8Lx4fXoX2ysDmi8kmBSE2IR1fMCRvB6FbYWM3TyT1L0812djw)|
|[](https://a.tribalfusion.com/i.match?p=b6&u=&google_push=AXcoOmQ3Q09FX-i_qxMQv5idSxOpduYNtFPBCgezGTH-GGHqct-lXR0PUd5f7kpHL9LgcykoU98Wzl5iobiMO5iIJl3avyRRSABM-u9esu_ltmNKjhBYXEibpYjAYRvTqi6Xfo8FHiK2mBdZ0dNOo8muDR6iag&redirect=https%3A//cm.g.doubleclick.net/pixel%3Fgoogle_nid%3Dexp%26google_push%3DAXcoOmQ3Q09FX-i_qxMQv5idSxOpduYNtFPBCgezGTH-GGHqct-lXR0PUd5f7kpHL9LgcykoU98Wzl5iobiMO5iIJl3avyRRSABM-u9esu_ltmNKjhBYXEibpYjAYRvTqi6Xfo8FHiK2mBdZ0dNOo8muDR6iag%26google_ula%3D2786954%26google_hm%3D%24TF_USER_ID_ENC%24)|
|[](https://www.google.com/recaptcha/api2/aframe)|

PASSED AUDITS (5)

Show

![ref2]

[](https://developers.google.com/web/fundamentals/security/prevent-mixed-content/what-is-mixed-content?utm_source=lighthouse&utm_medium=devtools)[](https://web.dev/is-on-https/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/image-aspect-ratio/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/serve-responsive-images/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://web.dev/deprecations/?utm_source=lighthouse&utm_medium=devtools)

![ref2]

[](https://developers.google.com/web/tools/chrome-devtools/javascript/source-maps?utm_source=lighthouse&utm_medium=devtools)

NOT APPLICABLE (1)

Show

![ref2]

[](https://web.dev/preload-optional-fonts/?utm_source=lighthouse&utm_medium=devtools)

Captured at Aug 9, 2023, 8:46 AM PDT

Emulated Desktop with Lighthouse 9.6.8

Single page load

Initial page load

Custom throttling

Using Chromium 109.0.0.0 with devtools

Generated by **Lighthouse** 9.6.8 | [File an issue](https://github.com/GoogleChrome/Lighthouse/issues)

[Screenshot]: Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.004.jpeg
[Screenshot]: Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.005.jpeg
[ref1]: Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.011.png
[ref2]: Aspose.Words.64a930f1-77aa-48af-8506-f5e7c330fdbb.012.png
